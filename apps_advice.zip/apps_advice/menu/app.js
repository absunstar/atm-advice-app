module.exports = function init(site){
    site.get({name:'images' , path: __dirname + '/site_files/images/'})
}