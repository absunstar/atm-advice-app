- barcode option in default setting

add table button to view all tables in colors by status
create customer items list
create offer items list
create price item list



# invoice
- add multi headers
- add multi footers
- add logo image
- add top title
