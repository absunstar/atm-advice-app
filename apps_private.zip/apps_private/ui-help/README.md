# Show Help Info

## HTML Code
```html
<input help-id="ab123">
```

## JSON Code

- Create help.json File in json Folder
```json
[
    {
        "id":"ab123" , "ar" : "شرح عربى" , "en":"English Description"
    }
]
```